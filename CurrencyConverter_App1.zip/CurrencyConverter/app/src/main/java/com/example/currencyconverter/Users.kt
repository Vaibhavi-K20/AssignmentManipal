package com.example.currencyconverter

class Users {
  var id : Int = 0
  var name :String = ""
    //var base :String = ""

}