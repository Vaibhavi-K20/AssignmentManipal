package com.example.recyclerviewdemo

import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.create
import retrofit2.http.GET
import retrofit2.http.Query

//http://newsapi.org/v2/everything?q=bitcoin&from=2020-10-20&sortBy=publishedAt&apiKey=API_KEY
//http://newsapi.org/v2/top-headlines?country=us&category=business&apiKey=API_KEY

const val BASE_URL = "https://newsapi.org/"
const val API_KEY  = "acbf05cb82074db292a102a8dcf3816b"

class RetrofitClient {
    interface APIInterface
    {
        @GET(
            "v2/top-headlines?apiKey=$API_KEY")

        fun getHeadlines( @Query("country") country: String, @Query("page") page : Int ) :Call<News>


    }

    object newService{
        val newsInstace: APIInterface

        init {
            val retrofit = Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
            newsInstace = retrofit.create(APIInterface::class.java)
        }


    }

}