package com.example.recyclerviewdemo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_main.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    lateinit var adapter: NewsAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        getNews()
    }
    private fun getNews()
    {
         val news = RetrofitClient.newService.newsInstace.getHeadlines("in",1)
          news.enqueue(object : Callback<News>
          {
              override fun onFailure(call: Call<News>, t: Throwable)
              {
                  Log.e("mytag","error is" +t)


              }

              override fun onResponse(call: Call<News>, response: Response<News>)
              {
                    val news = response.body()
                  if(news!= null)
                  {
                      Log.e("sss",news.toString())
                      adapter = NewsAdapter(this@MainActivity,news.articles)
                      newslist.adapter = adapter
                      newslist.layoutManager = LinearLayoutManager(this@MainActivity)
                  }
              }
          })

    }
}